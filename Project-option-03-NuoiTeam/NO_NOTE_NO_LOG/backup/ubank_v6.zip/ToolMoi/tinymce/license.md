Copyright (c) 2025 Ephox Corporation DBA Tiny Technologies, Inc.

SOFTWARE TERMS & CONDITIONS OF USE

Licensed under, and subject to the restrictions of:
1. The terms of [GNU General Public License Version 2 or later](http://www.gnu.org/licenses/gpl.html); or
2. The Tiny Technologies, Inc Software Terms & Conditions of Use presented at <https://about.tiny.cloud/legal/> and specifically the Tiny Self-Hosted License Agreement, unless you have signed a negotiated commercial license agreement with us in which case your use is governed by those terms. By use of this Software you have agreed to these Tiny Technologies, Inc Software Terms & Conditions of Use.

If you are uncertain about your licensing requirements, please contact <sales@tiny.cloud> for further clarification.
