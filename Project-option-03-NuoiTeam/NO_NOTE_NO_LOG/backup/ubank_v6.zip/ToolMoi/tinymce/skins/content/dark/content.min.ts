export interface Classes {
  "mce-content-body": string;
};
