// Debug test - simple variable reference
const VAR_A = "Content of A";
const VAR_B = VAR_A;

const simpleData = {
    "Test": {
        displayName: "Simple Test",
        pdf: "test.pdf",
        note: VAR_B,
        xmttib: "",
        xmttecom: ""
    }
};
